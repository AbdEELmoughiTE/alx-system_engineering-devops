0. Where am I?
